package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

    private final DataService dataService;

    @Autowired
    public MyController(DataService dataService) {
        this.dataService = dataService;
    }

    @GetMapping("/hello")
    public String hello() {
        return "Hello, Azure!";
    }

    @GetMapping("/data")
    public List<DataItem> fetchData() {
        return dataService.fetchDataFromDatabase();
    }
}