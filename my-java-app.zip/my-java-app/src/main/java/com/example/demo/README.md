# My Java Web Application

This is a Java web application that demonstrates how to connect to an Azure SQL Database through a private endpoint.

## Setup

1. Clone this repository.
2. Configure the `application.properties` or `application.yml` file with your database connection details.
3. Build and deploy the application to Azure App Service.
4. Access the application at https://your-web-app-url.com.

## Database Connectivity

- The application connects to an Azure SQL Database for data storage.
- Modify the `DataService.java` file to customize database queries.
