import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public static Connection getConnection() {
        String jdbcUrl = "jdbc:sqlserver://sql-pvt-ep-instance.database.windows.net:1433;database=demo-ssp-sql-db";
        String username = "kiran";
        String password = "Killer@912";

        Connection connection = null;

        try {
            connection = DriverManager.getConnection(jdbcUrl, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to connect to the database.");
        }

        return connection;
    }
}